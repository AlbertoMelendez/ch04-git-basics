# Exercise 3

Learn the basics of git workflow:

1. **Fork** the repo onto your own github account  
(maybe you already did it)

2. clone it to your laptop  
`git clone ...`

3. add greetings on top of this file.  Feel free to do more changes!

4. commit your changes:  
`git commit -am "<explain what did you do>"`

5. send your edits back to GitHub
`git push`

6. check the repo on your github account.  Did it work?
