# Exercise 2

This exercise introduces git branches.  In git you can split your
development into different branches, and change some of these, and
merge the changes back to the others.

1. This exercise comes in two branches: a) master -- this version, and
   b) complete -- a version with solutions.
   
   list all the versions using git.

2. Modify this version, by answering the question above ;-)

